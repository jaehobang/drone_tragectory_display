
#include <joint_mapping/Logger.h>

Logger* Logger::s_instance = 0;
