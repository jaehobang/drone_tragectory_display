
/* 
In charge of all file outputs. Basically the old mast_example utils file
*/

bool writeMATLABfilePacketSize(std::string filename, const std::vector<size_t>& network_usage);
